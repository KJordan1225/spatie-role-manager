<div class="row" id="sortable">

    <?php $__empty_1 = true; $__currentLoopData = $documents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $document): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="col-md-6 mb-3 documentContentClass " id="<?php echo e($document->id); ?>">
            <div class="custom-card <?php echo e($document->extension ? '' : 'bg-light-red'); ?>" draggable="true">

                <div class="<?php echo e(!in_array($document->extension, getImageExtensions()) ? 'img-container' : 'img-container-file'); ?>"
                    onclick="previewCourseFile('<?php echo e($document->extension); ?>', '<?php echo e(asset($document->file_path)); ?>')"
                    data-previewFile="<?php echo e($document->getFileIcon()); ?>">
                    <img src="<?php echo e($document->getFileIcon()); ?>" width="0" height="0" alt=""
                        id="filePreviewId" />
                </div>

                <div class="card-content" onclick="selectCard(this)" data-id="<?php echo e($document->id); ?>",
                    data-name="<?php echo e($document->name); ?>" data-url="<?php echo e($document->url); ?>"
                    data-path="<?php echo e($document->file_path); ?>" data-folder="<?php echo e($document->folder_id); ?>"
                    data-owner="<?php echo e($document->owner); ?>" data-contact="<?php echo e($document->contact); ?>"
                    data-img="<?php echo e($document->getFileIcon()); ?>" data-visibility="<?php echo e($document->isPublic()); ?>"
                    data-file_type="<?php echo e($document->extension); ?>">
                    <div class="d-flex justify-content-between">
                        <div class="card-title"><?php echo e($document->name); ?> <br>
                            <?php if($document->tags): ?>
                                <?php $__currentLoopData = $document->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <a href="javascript:void()"> <small class="mt-0"><?php echo e($tag->name); ?></small></a>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </div>
                        <div class="form-check">
                            <input class="form-check-input" class="card-radio" type="radio" id="radio1"
                                name="radio">
                            <?php if($document->visibility === 'public'): ?>
                                <i class="fa fa-unlock mr-5" style="margin-right: 1rem"></i>
                            <?php else: ?>
                                <i class="fa fa-lock text-danger mr-5"></i>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="date-emojis">
                        <div class="date"><?php echo e($document->created_at?->format('d/m/Y')); ?></div>
                        <div class="emojis"><i class="fa fa-clock"></i> <?php if (isset($component)) { $__componentOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.avatar','data' => ['width' => '20','height' => '20']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('avatar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['width' => '20','height' => '20']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b)): ?>
<?php $attributes = $__attributesOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b; ?>
<?php unset($__attributesOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b)): ?>
<?php $component = $__componentOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b; ?>
<?php unset($__componentOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b); ?>
<?php endif; ?></div>
                    </div>
                </div>
            </div>
        </div>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <div class="col-md-6 mb-3 documentContentClass">
            <div class="no-document-found">
                <img src="<?php echo e(asset('img/empty-document.png')); ?>" alt="No Document Found Image">
                <p>No document found</p>
            </div>
        </div>
    <?php endif; ?>
</div>

<style>
    .custom-card>.img-container-file img {
        width: 70px;
        height: 70px;
        display: block;
        margin: 0 auto;
        object-fit: inherit;
    }

    .card-content {
        cursor: pointer;
    }
</style>

<style>
    .no-document-found {
        text-align: center;
        padding: 20px;
        margin: auto;
        background-color: whitesmoke;
        width: 60vw;
    }

    .no-document-found img {
        width: 200px;
        /* Adjust size as needed */
        height: auto;
        /* Maintain aspect ratio */
        margin-bottom: 20px;
    }

    .no-document-found p {
        font-size: 18px;
        color: #333;
        /* Adjust color as needed */
    }
</style>

<script>
    $(document).ready(function() {
        $("#sortable").sortable({
            containment: "parent", // Contain within the parent element
            cursor: "move",
            update: function(event, ui) {
                updateDocumentOrder();
            }
        });

        // Function to update document order via AJAX
        function updateDocumentOrder() {
            var documentIds = $("#sortable").sortable("toArray");
            var selectedFolderId = localStorage.getItem('selectedFolderId');

            // Send AJAX request to update document order
            $.ajax({
                url: '/update-document-order',
                type: 'POST',
                data: {
                    document_ids: documentIds,
                    folder_id: selectedFolderId
                },
                headers: {
                    'X-CSRF-TOKEN': csrfToken
                },
                success: function(response) {
                    console.log('Document order updated successfully.');
                },
                error: function(xhr, status, error) {
                    // Handle error
                    console.error('Error updating document order:', error);
                    alert('Error updating document order:', error)
                    // $('.errorMessage').html(error);
                }
            });
        }

    });
</script>
<?php /**PATH /home/lazhorus/laravel/spatie-permissions/spatie-role-manager/resources/views/documents/contents.blade.php ENDPATH**/ ?>