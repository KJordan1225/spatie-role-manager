<?php $__env->startSection('content'); ?>
<div class="row" style="margin-left: 250px;">
    <div class="col-lg-12 margin-tb">
        <div class="pull-left">
            <h2> Show User</h2>
        </div>
        <div class="pull-right">
            <a class="btn btn-primary" href="<?php echo e(route('manage.users.index')); ?>"> Back</a>
        </div>
    </div>
</div>

<div class="row" style="margin-left: 250px;">
    <div class="col-xs-12 col-sm-12 col-md-12">
        <div class="form-group">
            <strong>Name:</strong>
            <?php echo e($user->name); ?>

        </div>
    </div>
    <div class="col-xs-12 col-sm-12 col-md-12">
        <div class="form-group">
            <strong>Email:</strong>
            <?php echo e($user->email); ?>

        </div>
    </div>
    <div class="col-xs-12 col-sm-12 col-md-12">
        <div class="form-group">
            <strong>Roles:</strong>            
            <?php if(!empty($user->getRoleNames())): ?>
                <?php $__currentLoopData = $user->getRoleNames(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <label class="badge bg-success"><?php echo e($v); ?></label>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </div>
    </div>
    <br />
    <br />
    <div class="col-xs-12 col-sm-12 col-md-12">
        <div class="form-group">
            <strong>User profile</strong>            
        </div>
    </div>
    <?php if($userProfile): ?>
        <br />
        <?php if($userProfile->profile_image): ?>   
            <div class="row" style="margin-left: 250px;">
                <div class="col-xs-12 col-sm-12 col-md-12">
                    <div class="form-group">
                        <img src="<?php echo e(asset('storage/' . $userProfile->profile_image)); ?>" alt="Profile Image" style="width: 150px; height: 150px; border: 1px solid #000; padding: 5px; margin: 10px;">
                    </div>
                </div>
            </div>
        <?php endif; ?>
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Name:</strong>
                <?php echo e($userProfile->first_name); ?> <?php echo e($userProfile->last_name); ?>

            </div>
        </div>
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Address ln 1:</strong>
                <?php echo e($userProfile->address1); ?>

            </div>
        </div>
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Address ln 2:</strong>
                <?php echo e($userProfile->address2); ?>

            </div>
        </div>
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>City:</strong>
                <?php echo e($userProfile->city); ?>

            </div>
        </div>
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>State:</strong>
                <?php echo e($userProfile->state); ?>

            </div>
        </div>
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Zip Code:</strong>
                <?php echo e($userProfile->zip_code); ?>

            </div>
        </div>
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Phone Number and type:</strong>
                <?php echo e($userProfile->phone_number); ?> <?php echo e($userProfile->phone_type); ?>

            </div>
        </div>
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Birthdate:</strong>
                <?php echo e($userProfile->dob); ?>

            </div>
        </div>
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Queversary:</strong>
                <?php echo e($userProfile->queversary); ?>

            </div>
        </div>
    <?php else: ?>
        <strong>No profile info saved.</strong>
    <?php endif; ?>    
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make($layout, array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/lazhorus/laravel/spatie-permissions/spatie-role-manager/resources/views/manage/users/show.blade.php ENDPATH**/ ?>