<?php $__env->startSection('content'); ?>
    <div class="errorMessage"></div>

    <div class="row">
        <div class="col-md-9 " id="documentContent">
            <div id="renderDocumentContentHtml">
                <?php if($documents->isEmpty()): ?>
                    <?php if (isset($component)) { $__componentOriginalfd4f8a449549a9bf215e5852b4652a8c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalfd4f8a449549a9bf215e5852b4652a8c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.notFound','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('notFound'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalfd4f8a449549a9bf215e5852b4652a8c)): ?>
<?php $attributes = $__attributesOriginalfd4f8a449549a9bf215e5852b4652a8c; ?>
<?php unset($__attributesOriginalfd4f8a449549a9bf215e5852b4652a8c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalfd4f8a449549a9bf215e5852b4652a8c)): ?>
<?php $component = $__componentOriginalfd4f8a449549a9bf215e5852b4652a8c; ?>
<?php unset($__componentOriginalfd4f8a449549a9bf215e5852b4652a8c); ?>
<?php endif; ?>
                <?php endif; ?>
            </div>
        </div>

        <div class="col-md-3 pl-0" id="documentProperty">

            <div class="row">
                <div class="col-md-12">

                    <?php echo $__env->make('documents.info', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

                </div>
                <div class="col-md-7" id="documentCommentSection" style="display: none">
                    <div id="renderDocumentCommentHtml"></div>
                </div>
            </div>

        </div>
    </div>


    <style>
        #documentContent {
            max-height: 80vh;
            overflow-y: auto;
            overflow-x: hidden;
        }

        /* Hide scrollbar track */
        ::-webkit-scrollbar-track {
            background: transparent;
        }

        /* scrollbar itself */
        ::-webkit-scrollbar {
            width: 8px;
            /* width of the scrollbar */
        }

        /* Handle when mouse is over the scrollbar */
        ::-webkit-scrollbar-thumb {
            background-color: #ccc4c4;
            /* color of the scrollbar handle */
            border-radius: 2px;
            /* border radius of the scrollbar handle */
        }

        /* Handle when scrollbar is being dragged */
        ::-webkit-scrollbar-thumb:hover {
            background-color: #ccc4c4;
            /* darker color when hovered */
        }
    </style>

    <?php echo $__env->make('documents.uploads.addUrl', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php echo $__env->make('documents.uploads.uploadFolder', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php echo $__env->make('documents.uploads.requestDocument', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php echo $__env->make('documents.uploads.shareDocument', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.docmanager-app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/lazhorus/laravel/spatie-permissions/spatie-role-manager/resources/views/documents/index.blade.php ENDPATH**/ ?>