<?php $__env->startSection('content'); ?>
    <h1 class="text-xl font-bold mb-4">Email Verification Required</h1>
    <p class="mb-4">Thanks for signing up! Please check your email to verify your address before continuing.</p>

    <?php if(session('status') == 'verification-link-sent'): ?>
        <div class="text-green-600">
            A new verification link has been sent to your email address.
        </div>
    <?php endif; ?>

    <form method="POST" action="<?php echo e(route('verification.send')); ?>">
        <?php echo csrf_field(); ?>
        <button type="submit" class="btn btn-primary mt-4">Resend Verification Email</button>
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.guest', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/kjordan/laravel/gawebapp/GAWEBAPP2/resources/views/auth/verify-email.blade.php ENDPATH**/ ?>