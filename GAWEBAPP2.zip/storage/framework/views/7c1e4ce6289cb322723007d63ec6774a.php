<?php $__env->startSection('content'); ?> 

    <style>
        .my-custom-container {
            width: 800px;
        }
    </style>

    <div class="d-flex justify-content-center">
        <div class="my-custom-container bg-light p-4 shadow rounded"> 

            <div class="container">
                <h1 class="text-center">Upcoming Events</h1>
            </div>

            <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="card" style="width: 100%;">
                    <div class="card-body">
                        <h5 class="card-title"><?php echo e($event->name); ?></h5>
                        <h5 class="card-text">Start Date: <?php echo e(\Carbon\Carbon::parse($event->start_date)->format('F d, Y h:i A')); ?></h5>
                        <h5 class="card-text">End Date: <?php echo e(\Carbon\Carbon::parse($event->end_date)->format('F d, Y h:i A')); ?></h5>
                        <h5 class="card-text">Location: <?php echo e($event->location); ?></h5>
                        <a href="<?php echo e(route('event.public-details', $event->id)); ?>" class="btn btn-primary">View Details</a>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.guest', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/kjordan/laravel/gawebapp/GAWEBAPP2/resources/views/guest_pages/last_five_list.blade.php ENDPATH**/ ?>