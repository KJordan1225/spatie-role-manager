<!-- Upload Modal -->


<style>
    .custom-a {
        font-size: 14px;
        color: rgb(6, 112, 112);
        margin-top: 5px;
        text-decoration: none;
    }
</style>


<?php if (isset($component)) { $__componentOriginal9f64f32e90b9102968f2bc548315018c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9f64f32e90b9102968f2bc548315018c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.modal','data' => ['modalId' => 'createFolderTagsModal','modalTitle' => 'Create Tags Categories','buttonText' => 'Save & Close','backDrop' => 'static','modalFade' => '','onclick' => 'saveFolderCategoryTag(\'close\')','closeModal' => 'closeFolderTagModal','onclickOnclose' => 'saveFolderCategoryTag']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['modalId' => 'createFolderTagsModal','modalTitle' => 'Create Tags Categories','buttonText' => 'Save & Close','backDrop' => 'static','modalFade' => '','onclick' => 'saveFolderCategoryTag(\'close\')','closeModal' => 'closeFolderTagModal','onclickOnclose' => 'saveFolderCategoryTag']); ?>
    <form id="FolderTagsForm">
        <div class="error-message"></div>
        <!-- URL Input -->
        <label for="fileName" class="custom-label">Name</label>
        <div class="form-group col-md-6">
            <input type="text" autocomplete="false" placeholder="E.g Status"
                class="form-control custom-input-lg col-md-6" id="CategoryName" name="category_name">
        </div>
        <div class="form-group1 col-md-12">
            <label for="tags" class="custom-label">Tags</label>
            <div id="inputContainer">
                <div class="inputRow input-group">
                    <i class="fa fa-arrows mt-2"></i>
                    <input type="text" name="tags[]" onkeydown="tagsEnter(event)" class="form-control custom-input">
                    <i class="fa fa-trash-can mt-3 popover" onclick="removeInputRow(this)"></i>
                </div>
            </div>
        </div>
        <a href="#" class="custom-a" id="addInputBtn" onclick="addInputRow()">Add a line</a>
    </form>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9f64f32e90b9102968f2bc548315018c)): ?>
<?php $attributes = $__attributesOriginal9f64f32e90b9102968f2bc548315018c; ?>
<?php unset($__attributesOriginal9f64f32e90b9102968f2bc548315018c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9f64f32e90b9102968f2bc548315018c)): ?>
<?php $component = $__componentOriginal9f64f32e90b9102968f2bc548315018c; ?>
<?php unset($__componentOriginal9f64f32e90b9102968f2bc548315018c); ?>
<?php endif; ?>



<script>
    function saveFolderCategoryTag(type) {

        var form = document.getElementById('FolderTagsForm');
        var $form = $('#FolderTagsForm');
        var formData = new FormData();

        // Iterate through form elements
        for (var pair of new FormData(form)) {
            // Check if the input value is not empty
            if (pair[1].trim() !== '') {
                // Add the non-empty input to formData
                formData.append(pair[0], pair[1]);
            }
        }

        formData.append('_token', csrfToken);
        formData.append('folder_name', $('#folderNameInput').val());
        formData.append('parent_id', $('#folderParentNameInput').val());

        $.ajax({
            url: <?php echo json_encode(route('tags.store'), 15, 512) ?>, // Replace with your server endpoint
            type: 'POST',
            data: formData,
            processData: false,
            contentType: false,
            success: function(response) {
                // fetchFiles(response.url);

                if (type === 'close') {
                    closeFolderTagModal();
                    $('#FolderTagsForm')[0].reset();
                } else {
                    $('#FolderTagsForm')[0].reset();
                }
                $('#renderFolderCategoryHtml').html(response.html);

            },
            error: function(xhr, status, error) {
                validation(xhr, $form);
            }
        });
    }


    function FolderTagsModal() {
        $('#createFolderTagsModal').modal('show');
        $('#createFolderModal').modal('hide');
    }

    function closeFolderTagModal() {
        $('#createFolderTagsModal').modal('hide');
        $('#createFolderModal').modal('show');
    }
</script>
<?php /**PATH /home/lazhorus/laravel/spatie-permissions/spatie-role-manager/resources/views/folders/modals/addTag.blade.php ENDPATH**/ ?>