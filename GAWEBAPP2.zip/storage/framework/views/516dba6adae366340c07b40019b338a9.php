<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><?php echo e(__('Brother Dashboard')); ?></div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    <?php $__sessionArgs = ['error'];
if (session()->has($__sessionArgs[0])) :
if (isset($value)) { $__sessionPrevious[] = $value; }
$value = session()->get($__sessionArgs[0]); ?>
                        <div class="alert alert-danger" role="alert"> 
                            <?php echo e($value); ?>

                        </div>
                    <?php unset($value);
if (isset($__sessionPrevious) && !empty($__sessionPrevious)) { $value = array_pop($__sessionPrevious); }
if (isset($__sessionPrevious) && empty($__sessionPrevious)) { unset($__sessionPrevious); }
endif;
unset($__sessionArgs); ?>

                    <?php if($profile === null): ?>
                    <?php else: ?>
                    <table class="table table-bordered" id="profileTable">                        
                        <tr>
                            <td width="100px">                                
                                <img src="<?php echo e(asset('storage/' . $profile->profile_image)); ?>" alt="No Profile Image Uploaded" style="width: 100px; height: 100px; object-fit: cover;" class="img-fluid rounded-circle">
                            </td>
                            <td width="300px">
                                Name: <?php echo e($profile->last_name); ?>, <?php echo e($profile->first_name); ?><br />
                                Address: <?php echo e($profile->address1); ?><br />
                                        <?php echo e($profile->city); ?>, <?php echo e($profile->state); ?> <?php echo e($profile->zip_code); ?><br />            
                                Email: <?php echo e($profile->user->email); ?><br />
                                Phone: <?php echo e($profile->phone_number); ?>&nbsp;-&nbsp;<?php echo e($profile->phone_type); ?><br />
                            </td>
                        </tr>
                    </table>
                    <?php endif; ?>

                    <?php echo e(__('You are logged in! Brother Dashboard')); ?>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.brotherDashboard', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/kjordan/laravel/gawebapp/GAWEBAPP2/resources/views/brotherdash.blade.php ENDPATH**/ ?>