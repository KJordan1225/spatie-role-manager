<?php $__env->startSection('content'); ?> 

    <style>
        .my-custom-container {
            width: 900px;
        }
    </style>

    <div class="d-flex justify-content-center">
        <div class="my-custom-container bg-light p-4 shadow rounded"> 

<?php echo $event->content; ?>


        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.guest', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/kjordan/laravel/gawebapp/GAWEBAPP2/resources/views/guest_pages/event-details.blade.php ENDPATH**/ ?>