<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><?php echo e(__('Test View')); ?></div>

                <div class="card-body">
                    <!-- <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?> -->
                    <?php if(isset($message)): ?>
                        <div class="alert alert-success">
                            <?php echo e($message); ?>

                        </div>
                    <?php endif; ?>

                    <?php $__sessionArgs = ['success'];
if (session()->has($__sessionArgs[0])) :
if (isset($value)) { $__sessionPrevious[] = $value; }
$value = session()->get($__sessionArgs[0]); ?>
                        <div class="alert alert-success" role="alert"> 
                            <?php echo e($value); ?>                            
                        </div>
                    <?php unset($value);
if (isset($__sessionPrevious) && !empty($__sessionPrevious)) { $value = array_pop($__sessionPrevious); }
if (isset($__sessionPrevious) && empty($__sessionPrevious)) { unset($__sessionPrevious); }
endif;
unset($__sessionArgs); ?>

                    <?php $__sessionArgs = ['error'];
if (session()->has($__sessionArgs[0])) :
if (isset($value)) { $__sessionPrevious[] = $value; }
$value = session()->get($__sessionArgs[0]); ?>
                        <div class="alert alert-danger" role="alert"> 
                            <?php echo e($value); ?>                            
                        </div>
                    <?php unset($value);
if (isset($__sessionPrevious) && !empty($__sessionPrevious)) { $value = array_pop($__sessionPrevious); }
if (isset($__sessionPrevious) && empty($__sessionPrevious)) { unset($__sessionPrevious); }
endif;
unset($__sessionArgs); ?>

                    <table class="table table-bordered" id="profileTable">                        
                        <tr>
                            <td width="100px"><!-- Profile Image -->
                                <img src="<?php echo e(asset('storage/' . $profile->profile_image)); ?>" alt="No Profile Image Uploaded" style="width: 100px; height: 100px; object-fit: cover;" class="img-fluid rounded-circle"></td>
                            <td width="300px">
                                Name: <?php echo e($profile->last_name); ?>, <?php echo e($profile->first_name); ?><br />
                                Address: <?php echo e($profile->address1); ?><br />
                                        <?php echo e($profile->city); ?>, <?php echo e($profile->state); ?> <?php echo e($profile->zip_code); ?><br />            
                                Email: <?php echo e($profile->user->email); ?> <br />
                                Phone: <?php echo e($profile->phone_number); ?> <?php echo e($profile->phone_type); ?>

                            </td>
                        </tr>
                    </table>
                    
                    <br /><br />

                    <?php if(Auth::check()): ?>
                        <?php echo e(__('You are logged in! Brother Dashboard')); ?>

                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make($layout, array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/kjordan/laravel/gawebapp/GAWEBAPP2/resources/views/myProfile/index.blade.php ENDPATH**/ ?>