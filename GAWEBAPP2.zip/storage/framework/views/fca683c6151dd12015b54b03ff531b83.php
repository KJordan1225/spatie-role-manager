<?php $__env->startSection('content'); ?>

<div class="row" style="margin-left: 250px;">
    <div class="col-lg-12 margin-tb">
        <div class="pull-left">
            <h1>Gamma Alpha Chapter Directory</h1>
        </div>        
    </div>
</div>

<table class="table table-bordered" style="margin-left: 250px;" id="profileTable">
  <tr>
     <th width="50px">Image</th>
     <th width="500px">Information</th>
  </tr>

    <?php $__currentLoopData = $profiles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $profile): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

  <tr>
        <td><!-- Profile Image -->
            <img src="<?php echo e(asset('storage/' . $profile->profile_image)); ?>" alt="No Profile Image Uploaded" style="width: 100px; height: 100px; object-fit: cover;" class="img-fluid rounded-circle"></td>
        <td>
            Name: <?php echo e($profile->last_name); ?>, <?php echo e($profile->first_name); ?><br />
            Address: <?php echo e($profile->address1); ?><br />
                    <?php echo e($profile->city); ?>, <?php echo e($profile->state); ?> <?php echo e($profile->zip_code); ?><br />            
            Email: <?php echo e($profile->user->email); ?>

        </td>
    </tr>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</table>

<div class="row" style="margin-left: 250px;">
    <div class="col-lg-12 margin-tb">        
        <div class="pull-right">
            <a class="btn btn-success btn-sm mb-2" href="<?php echo e(route('chapter_directory.generatepdf')); ?>"><i class="fa fa-plus"></i> Generate PDF</a>
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make($layout, array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/kjordan/laravel/gawebapp/GAWEBAPP2/resources/views/chapter_directory/view.blade.php ENDPATH**/ ?>