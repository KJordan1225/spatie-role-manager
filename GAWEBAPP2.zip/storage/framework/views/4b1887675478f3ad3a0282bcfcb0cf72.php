<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['message' => 'No document found', 'size' => '60']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['message' => 'No document found', 'size' => '60']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>
<div class="col-md-12 mb-3 documentContentClass">
    <div class="no-document-found">
        <img src="<?php echo e(asset('img/empty-document.png')); ?>" alt="No Document Found Image">
        <p><?php echo e($message); ?></p>
    </div>
</div>


<?php if (! $__env->hasRenderedOnce('395bf0be-bd0f-42ba-b052-ad490d4079f1')): $__env->markAsRenderedOnce('395bf0be-bd0f-42ba-b052-ad490d4079f1'); ?>
    <style>
        .no-document-found {
            text-align: center;
            padding: 20px;
            margin: auto;
            background-color: whitesmoke;
            width: <?php echo e($size); ?>vw;
        }

        .no-document-found img {
            width: 200px;
            /* Adjust size as needed */
            height: auto;
            /* Maintain aspect ratio */
            margin-bottom: 20px;
        }

        .no-document-found p {
            font-size: 18px;
            color: #333;
            /* Adjust color as needed */
        }
    </style>
<?php endif; ?><?php /**PATH /home/lazhorus/laravel/spatie-permissions/spatie-role-manager/resources/views/components/notFound.blade.php ENDPATH**/ ?>