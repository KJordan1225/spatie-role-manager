<?php $__env->startSection('content'); ?>
<div class="container mx-auto p-4 bg-white rounded shadow w-100" style="margin-left: 200px;">

    <?php if(session('success')): ?>
        <div class="alert alert-success" role="alert" style="margin-left: 200px;"> 
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <div class="row" style="margin-left: 200px;">
        <div class="col-lg-12 margin-tb">
            <div class="pull-left">
                <h2>Event List</h2>
            </div>
            <div class="pull-right">
                <a class="btn btn-success btn-sm mb-2" href="<?php echo e(route('event.create')); ?>"><i class="fa fa-plus"></i> Create New Event</a>
                &nbsp;&nbsp;&nbsp;
                <a class="btn btn-primary btn-sm mb-2" href="<?php echo e(route('welcome')); ?>"><i class="fa fa-arrow-left"></i> Goto Homepage</a>
            </div>
        </div>
    </div>

    <div class="overflow-x-auto" style="margin-left: 200px; width: 80%">        
        <?php if(count($events) > 0): ?>
        <table class="table table-bordered">
            <tr>
                <th width="35px">#</th>
                <th width="200px">Name</th>
                <th width="200px">Start Date and Time</th>
                <th width="250px">Location</th>
                <th width="210px">Action</th>
            </tr>
                <?php
                    $i=0;
                ?>
                <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>    
                <tr>
                    <td><?php echo e(++$i); ?></td>
                    <td><?php echo e($event->name); ?></td>
                    <td><?php echo e(\Carbon\Carbon::parse($event->start_date)->format('F d, Y h:i A')); ?></td>
                    <td><?php echo e($event->location); ?></td>
                    <td>
                        <a class="btn btn-info btn-sm" href="<?php echo e(route('event.show',$event->id)); ?>"><i class="fa-solid fa-list"></i> Show</a>
                        <a class="btn btn-primary btn-sm" href="<?php echo e(route('event.edit',$event->id)); ?>"><i class="fa-solid fa-pen-to-square"></i> Edit</a>
                        <form method="POST" action="<?php echo e(route('event.destroy',$event->id)); ?>" style="display:inline">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure you want to delete this event?')">Delete</button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
            <?php else: ?>
                <table class="table table-bordered">
                    <tr>
                        <th width="35px">#</th>
                        <th width="200px">Name</th>
                        <th width="150px">Start Date and Time</th>
                        <th width="250px">Location</th>
                        <th width="210px">Action</th>
                    </tr>
                    <tr>
                        <td colspan="5" class="text-center border px-4 py-4">
                            <h2>No events found.</h2>
                        </td>
                    </tr>
                </table>
            <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make($layout, array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/lazhorus/laravel/spatie-permissions/spatie-role-manager/resources/views/events/index.blade.php ENDPATH**/ ?>