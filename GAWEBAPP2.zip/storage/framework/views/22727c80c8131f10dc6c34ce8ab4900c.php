<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['width' => 50, 'height' => 50]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['width' => 50, 'height' => 50]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>

<a href="#" class="circle">
    <img height="<?php echo e($width); ?>" width="<?php echo e($height); ?>" src="<?php echo e(asset('img/profile.jpg')); ?>"
        alt="<?php echo e(Auth::user()->name); ?>">
</a>

<?php if (! $__env->hasRenderedOnce('9fa29a47-ce19-4c0e-bee8-ebee0839a884')): $__env->markAsRenderedOnce('9fa29a47-ce19-4c0e-bee8-ebee0839a884'); ?>
    <!-- Include CSS using once() method -->
    <style>
        /* Your CSS styles here */
        ::-moz-selection {
            background: rgba(0, 0, 0, 0.1);
        }

        ::selection {
            background: rgba(0, 0, 0, 0.1);
        }

        /* Circle Avatar Styles */

        .circle {
            /* Remove line-height */
            line-height: 0;
            /* Display inline-block */
            /* display: block; */
            margin: 5px;
            border: 1px solid rgba(200, 200, 200, 0.4);
            border-radius: 50%;
            /* box-shadow: 0px 0px 5px rgba(0, 0, 0, 0.4); */
            transition: linear 0.25s;
            /* Swap width and height */
            /* width: 10px;
                        height: 10px; */
        }

        .circle img {
            border-radius: 50%;
            /* relative value for adjustable image size */
        }

        .circle:hover {
            /* transition: ease-out 0.2s;
                        border: 1px solid rgba(0, 0, 0, 0.2);
                        -webkit-transition: ease-out 0.2s; */
        }

        a.circle {
            color: transparent;
        }

        /* IE fix: removes blue border */
    </style>
<?php endif; ?>
<?php /**PATH /home/lazhorus/laravel/spatie-permissions/spatie-role-manager/resources/views/components/avatar.blade.php ENDPATH**/ ?>