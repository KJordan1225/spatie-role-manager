<div class=" commentContent">

    <div class="card-header d-flex justify-content-between">
        <div class="tab-buttons">
            <button class="tab-btn active1" onclick="tabClicked(this)" content-id="home" title="Send Message">
                Message
            </button>
            <button class="tab-btn" onclick="tabClicked(this)" content-id="services" title="Log Note">
                Log note
            </button>
            
        </div>
        <i class="fa fa-times close-icon" onclick="closeComment()"></i>
    </div>

    <div class="tab-contents">
        <div class="tab-content show1" id="home">
            <div class1="content-info">
                <h1 class="content-title">
                    <?php if (isset($component)) { $__componentOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.avatar','data' => ['width' => '30','height' => '30']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('avatar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['width' => '30','height' => '30']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b)): ?>
<?php $attributes = $__attributesOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b; ?>
<?php unset($__attributesOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b)): ?>
<?php $component = $__componentOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b; ?>
<?php unset($__componentOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b); ?>
<?php endif; ?>
                </h1>
                <div class="content-description1">
                    <form id="sendDocumentFormId">
                        <input type="hidden" name="type" value="message">
                        <textarea class="custom-textarea" name="content" oninput="handleInputEvent(event)" id="messageInput"
                            placeholder="Type your message here..."></textarea>
                        <div id="userDropdown" class="userDropdown"></div>
                        <input type="hidden" name="user_email" class="form-control col-md-12 selectedUsersId"
                            id="selectedUsersId">
                        <button type="button" class="btn btn-sm btn-info"
                            onclick="sendEmail('sendDocumentFormId')">Send</button>
                    </form>
                </div>
            </div>
            
        </div>
        <div class="tab-content" id="services">
            <div class="content-info">
                <h1 class="content-title">
                    <?php if (isset($component)) { $__componentOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.avatar','data' => ['width' => '30','height' => '30']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('avatar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['width' => '30','height' => '30']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b)): ?>
<?php $attributes = $__attributesOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b; ?>
<?php unset($__attributesOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b)): ?>
<?php $component = $__componentOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b; ?>
<?php unset($__componentOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b); ?>
<?php endif; ?>
                </h1>
                <div class="content-description1">
                    <form id="sendDocumentLogFormId">
                        <input type="hidden" name="type" value="log">
                        <textarea class="custom-textarea" name="content" oninput1="handleInputEvent(event)" id="messageLogInput"
                            placeholder="Type your log here..."></textarea>
                        
                        <input type="hidden" name="user_email" class="form-control col-md-12 selectedUsersId"
                            id="selectedUsersId">
                        <button type="button" class="btn btn-sm btn-info"
                            onclick="sendEmail('sendDocumentLogFormId')">Send</button>
                    </form>
                </div>
            </div>
        </div>
        
    </div>
    </di>

    <?php $__empty_1 = true; $__currentLoopData = $notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $date => $notificationGroup): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <?php if($loop->first): ?>
            <div class="custom-date">
                <div class="line"></div>
                <h2><?php echo e($notificationGroup->date); ?></h2>
                <div class="line"></div>
            </div>
        <?php endif; ?>
        <div class="notif-card">
            <div class="card-body d-flex align-items-center">
                <?php if (isset($component)) { $__componentOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.avatar','data' => ['width' => '35','height' => '35']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('avatar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['width' => '35','height' => '35']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b)): ?>
<?php $attributes = $__attributesOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b; ?>
<?php unset($__attributesOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b)): ?>
<?php $component = $__componentOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b; ?>
<?php unset($__componentOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b); ?>
<?php endif; ?>
                <div class="info ml-5">
                    <h5 class="name"><?php echo e($notificationGroup?->user?->name ?? auth()->user()->name); ?> &nbsp;&nbsp;
                        <small><?php echo e($notificationGroup->created_at->diffForHumans()); ?></small>
                    </h5>
                    <p class="message"><?php echo e($notificationGroup->message); ?> </p>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <div class="notif-card-empty">
            <div class="card-body d-flex align-items-center">
                <h5 class="mx-auto"><i class="fa fa-comments"></i> No Comment</h5>
            </div>
        </div>
    <?php endif; ?>


    <style>
        .commentContent {
            background: white;
        }

        .notif-card {
            border: 1px solid #c0bfbf;
            /* border-radius: 8px; */
            overflow: hidden;
            width: 100%;
            background: #f7f6f6bf;
        }

        .notif-card-empty {
            border-bottom: 1px solid #9c9c9c;
            overflow: hidden;
            width: 100%;
            background: #e0e0e0bf;
            height: 100%;
        }

        .notif-card .card-body {
            padding: 2px;
        }

        .notif-card .avatar {
            width: 50px;
            height: 50px;
            border-radius: 50%;
        }

        .notif-card .info {
            flex-grow: 1;
        }

        .notif-card .name {
            margin: 0;
            font-size: 16px;
            margin-top: 2px;
            margin-left: 2px;
        }

        .notif-card .message {
            margin: 5px 0 0;
            font-size: 12px;
            color: #666;
            margin-left: 2px;

        }

        .highlight {
            color: rgb(37, 134, 173);
            /* Change to the color you desire */
        }
    </style>
<?php /**PATH /home/lazhorus/laravel/spatie-permissions/spatie-role-manager/resources/views/documents/comments.blade.php ENDPATH**/ ?>