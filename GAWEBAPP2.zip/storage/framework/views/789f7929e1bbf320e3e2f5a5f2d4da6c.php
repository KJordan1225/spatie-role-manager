<?php if (isset($component)) { $__componentOriginal9f64f32e90b9102968f2bc548315018c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9f64f32e90b9102968f2bc548315018c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.modal','data' => ['modalId' => 'uploadFolderModal','backDrop' => 'static','modalTitle' => 'Upload Folder','buttonText' => 'Upload','onclick' => 'submitUploadFormFolder()']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['modalId' => 'uploadFolderModal','backDrop' => 'static','modalTitle' => 'Upload Folder','buttonText' => 'Upload','onclick' => 'submitUploadFormFolder()']); ?>
    <form id="uploadFolderForm">
        <div class="error-message"></div>
        <!-- URL Input -->
        <div class="form-group">
            <label for="folderIdInput" class="custom-label mt-3">Parent Folder</label>
            <select name="folder_id" id="folderIdInput" class="form-control custom-input custom-select">
                <option value="">Parent</option>
                <?php echo generateDropdownOptions(); ?>

            </select>

        </div>
        <!-- Name Input -->
        <div class="form-group">
            <label for="directoryInput" class="custom-label mt-3">Select Folder</label>
            <input type="file" webkitdirectory multiple class="form-control custom-input" id="directoryInput"
                name="files">
        </div>
        <!-- Name Input -->
        <div class="form-group">
            <label for="folderNameInput" class="custom-label mt-3">Folder Name</label>
            <input type="text" class="form-control custom-input" id="folderNameInput" name="folder_name">
        </div>
        <!-- Visibility Checkbox -->
        <div class="form-check mt-3">
            <input class="form-check-input custom-checkbox mt-2" type="checkbox" id="visibilityCheckbox"
                name="visibility" value="public" checked>
            <label class="form-check-label custom-check-label" for="visibilityCheckbox">
                Make private
            </label>
        </div>
    </form>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9f64f32e90b9102968f2bc548315018c)): ?>
<?php $attributes = $__attributesOriginal9f64f32e90b9102968f2bc548315018c; ?>
<?php unset($__attributesOriginal9f64f32e90b9102968f2bc548315018c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9f64f32e90b9102968f2bc548315018c)): ?>
<?php $component = $__componentOriginal9f64f32e90b9102968f2bc548315018c; ?>
<?php unset($__componentOriginal9f64f32e90b9102968f2bc548315018c); ?>
<?php endif; ?>


<?php if (! $__env->hasRenderedOnce('ed243f03-f066-4c82-af9a-eeb9634a7489')): $__env->markAsRenderedOnce('ed243f03-f066-4c82-af9a-eeb9634a7489'); ?>
    <script src="<?php echo e(asset('custom-js/uploadFolder.js')); ?>"></script>
<?php endif; ?>
<?php /**PATH /home/lazhorus/laravel/spatie-permissions/spatie-role-manager/resources/views/documents/uploads/uploadFolder.blade.php ENDPATH**/ ?>