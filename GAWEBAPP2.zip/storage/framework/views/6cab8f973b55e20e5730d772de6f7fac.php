<?php $__env->startSection('content'); ?>
<div class="row" style="margin-left: 250px;">
    <div class="col-lg-12 margin-tb">
        <div class="pull-left">
            <h2>Update User Active Status</h2>
        </div>        
    </div>
    <div class="pull-right">
        <a class="btn btn-primary btn-sm mb-2" href="<?php echo e(route('manage.users.index')); ?>"><i class="fa fa-arrow-left"></i> Back</a>
    </div>
</div>

<?php $__sessionArgs = ['success'];
if (session()->has($__sessionArgs[0])) :
if (isset($value)) { $__sessionPrevious[] = $value; }
$value = session()->get($__sessionArgs[0]); ?>
    <div class="alert alert-success" role="alert" style="margin-left: 250px;"> 
        <?php echo e($value); ?>

    </div>
<?php unset($value);
if (isset($__sessionPrevious) && !empty($__sessionPrevious)) { $value = array_pop($__sessionPrevious); }
if (isset($__sessionPrevious) && empty($__sessionPrevious)) { unset($__sessionPrevious); }
endif;
unset($__sessionArgs); ?>

<form action="<?php echo e(route('manage.users.updateIsActive')); ?>" method="POST" id="formA">
    <?php echo csrf_field(); ?>

<table class="table table-bordered" style="margin-left: 250px; width: 80%;">
  <tr>
     <th width="25px">No</th>
     <th width="50px">Name</th>
     <th width="100px">Email</th>
	 <th width="50px"><input type="checkbox" id="selectAll">&nbsp;&nbsp;Active</th>
  </tr>
    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>    
    <tr>
        <td><?php echo e(++$i); ?></td>
        <td><?php echo e($user->name); ?></td>
		<td><?php echo e($user->email); ?></td>
		<td>           
            <!-- Hidden input for unchecked state, checkbox for checked state -->
            <input type="hidden" name="items[<?php echo e($user->id); ?>]" value="0">
            <input type="checkbox" name="items[<?php echo e($user->id); ?>]" value="1" class="itemCheckbox" <?php echo e($user->is_active ? 'checked' : ''); ?>>

        </td>       
    </tr>    
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>    

</table>

<input type="hidden" name="new_status" value="1">

<div class="row" style="margin-left: 250px;">
    <div class="col-xs-12 col-sm-12 col-md-12 text-center">
        <button type="submit" class="btn btn-primary btn-sm mt-2 mb-3">Update Active</button>
    </div>
</div>

</form>

<script>
    document.addEventListener('DOMContentLoaded', function () {
        document.getElementById('selectAll').addEventListener('change', function (event) {
            var checkboxes = document.querySelectorAll('.itemCheckbox');
            checkboxes.forEach(function(checkbox) {
                checkbox.checked = event.target.checked;
            });
        });
    });

</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make($layout, array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/lazhorus/laravel/spatie-permissions/spatie-role-manager/resources/views/manage/users/listIsActive.blade.php ENDPATH**/ ?>