<?php $__env->startSection('content'); ?>
<div class="row" style="margin-left: 250px;">
    <div class="col-lg-12 margin-tb">
        <div class="pull-left">
            <h2>User Profile Management</h2>
        </div>        
    </div>
</div>


<?php $__sessionArgs = ['success'];
if (session()->has($__sessionArgs[0])) :
if (isset($value)) { $__sessionPrevious[] = $value; }
$value = session()->get($__sessionArgs[0]); ?>
    <div class="alert alert-success" role="alert" style="margin-left: 250px;"> 
        <?php echo e($value); ?>

    </div>
<?php unset($value);
if (isset($__sessionPrevious) && !empty($__sessionPrevious)) { $value = array_pop($__sessionPrevious); }
if (isset($__sessionPrevious) && empty($__sessionPrevious)) { unset($__sessionPrevious); }
endif;
unset($__sessionArgs); ?>

<table class="table table-bordered" style="margin-left: 250px;" id="profileTable">
  <tr>
     <th width="100px">No</th>
     <th width="100px">Username</th>
     <th width="150px">Full Name</th>
	 <th width="100px">Profile Status</th>
	 <th width="280px">Action</th>
  </tr>
    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>    
    <tr>
        <td><?php echo e(++$i); ?></td>
        <td><?php echo e($user->name); ?></td>
        <td>
            <?php if($user->userProfile): ?>
                <?php echo e($user->userProfile->first_name); ?> <?php echo e($user->userProfile->last_name); ?> 
            <?php else: ?>
                No profile
            <?php endif; ?>
        </td>
        <td>
            <?php if($user->userProfile): ?>
                Profile 
            <?php else: ?>
                No profile
            <?php endif; ?>
        </td>
        <td>
            <!-- <a class="btn btn-info btn-sm" href="<?php echo e(route('manage.users.show',$user->id)); ?>"><i class="fa-solid fa-list"></i> Show</a> -->
            <!-- <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('user-edit')): ?> -->
             <?php if($user->userProfile): ?>
                <a class="btn btn-primary btn-sm" href="<?php echo e(route('manage.user_profiles.edit',$user->id)); ?>"><i class="fa-solid fa-pen-to-square"></i>Edit User Profile  </a>
             <?php else: ?>
                <a class="btn btn-primary btn-sm" href="<?php echo e(route('manage.user_profiles.create',$user->id)); ?>"><i class="fa-solid fa-pen-to-square"></i>Create User Profile</a>
             <?php endif; ?>                
            <!-- <?php endif; ?> -->
            <?php if($user->userProfile): ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('profile-delete')): ?>
                <form method="POST" action="<?php echo e(route('manage.user_profiles.destroy', $user->id)); ?>" style="display:inline">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>

                    <button type="submit" class="btn btn-danger btn-sm" id="delete-<?php echo e($i); ?>" onclick="return confirmDelete(this);">Delete</button>
                </form>
                <?php endif; ?>
            <?php endif; ?>
        </td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

     <?php echo $users->links('pagination::bootstrap-5'); ?>


</table>

<script>
    function confirmDelete(button) {
        // Confirm before submission
        return confirm("Are you sure you want to delete the pofile for this user?");
    }
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make($layout, array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/lazhorus/laravel/spatie-permissions/spatie-role-manager/resources/views/manage/user_profiles/index.blade.php ENDPATH**/ ?>