<?php if (isset($component)) { $__componentOriginal9f64f32e90b9102968f2bc548315018c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9f64f32e90b9102968f2bc548315018c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.modal','data' => ['modalId' => 'uploadModal','modalTitle' => 'Add Url','backDrop' => 'static','buttonText' => 'Add','onclick' => 'submitUploadForm()']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['modalId' => 'uploadModal','modalTitle' => 'Add Url','backDrop' => 'static','buttonText' => 'Add','onclick' => 'submitUploadForm()']); ?>
    <form id="uploadForm">
        <div class="error-message"></div>
        <!-- URL Input -->
        <div class="form-group">
            <label for="urlAddmodalInput" class="custom-label">URL</label>
            <input type="text" class="form-control custom-input" id="urlAddmodalInput" name="url"
                placeholder="Enter URL">
        </div>
        <!-- Name Input -->
        <div class="form-group">
            <label for="urlnameInput" class="custom-label">Name</label>
            <input type="text" class="form-control custom-input" id="urlnameInput" name="name"
                placeholder="Enter Name">
        </div>
        <!-- Visibility Checkbox -->
        <div class="form-check">
            <input class="form-check-input custom-checkbox" type="checkbox" id="visibilityUrlCheckbox" name="visibility"
                value="public" checked>
            <label class="form-check-label custom-check-label" for="visibilityUrlCheckbox">
                Make private
            </label>
        </div>
    </form>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9f64f32e90b9102968f2bc548315018c)): ?>
<?php $attributes = $__attributesOriginal9f64f32e90b9102968f2bc548315018c; ?>
<?php unset($__attributesOriginal9f64f32e90b9102968f2bc548315018c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9f64f32e90b9102968f2bc548315018c)): ?>
<?php $component = $__componentOriginal9f64f32e90b9102968f2bc548315018c; ?>
<?php unset($__componentOriginal9f64f32e90b9102968f2bc548315018c); ?>
<?php endif; ?>

<?php if (! $__env->hasRenderedOnce('4ef3793c-d9db-425e-b483-773b005a240f')): $__env->markAsRenderedOnce('4ef3793c-d9db-425e-b483-773b005a240f'); ?>
    <script src="<?php echo e(asset('custom-js/addUrl.js')); ?>"></script>
<?php endif; ?>
<?php /**PATH /home/lazhorus/laravel/spatie-permissions/spatie-role-manager/resources/views/documents/uploads/addUrl.blade.php ENDPATH**/ ?>