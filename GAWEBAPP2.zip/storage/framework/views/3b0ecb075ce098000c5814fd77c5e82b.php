<div>
    <h3>Name : <?php echo e($name); ?></h3>
    <h3>Email : <?php echo e($email); ?></h3>
    <h3>Message : <?php echo e($messageContent); ?></h3>
</div><?php /**PATH /home/kjordan/laravel/gawebapp/GAWEBAPP2/resources/views/emails/contact.blade.php ENDPATH**/ ?>