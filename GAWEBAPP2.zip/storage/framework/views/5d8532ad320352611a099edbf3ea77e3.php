<?php if(!is_null($folder)): ?>
    <?php echo renderTagsWithCategories($folder); ?>

<?php endif; ?>
<?php /**PATH /home/lazhorus/laravel/spatie-permissions/spatie-role-manager/resources/views/folders/categories.blade.php ENDPATH**/ ?>