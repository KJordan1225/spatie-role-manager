<!DOCTYPE html>
<html>
<head>
    <title>Gamma Alpha Chapter Directory</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" >
</head>
<body>
    <h1><?php echo e($title); ?></h1>
    <p><?php echo e($date); ?></p>
    <p>Testing the generation of PDF of chapter directory</p>

    <br />
  
    <table class="table table-bordered" id="profileTable">
  <tr>
     <th width="100px">Image</th>
     <th width="500px">Information</th>
  </tr>

    <?php $__currentLoopData = $profiles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $profile): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <?php if(empty($profile->profile_image)): ?>
            <?php 
                $url = 'storage/profiles/user-placeholder.png';
                $image = public_path ($url);
            ?>
        <?php else: ?>
            <?php 
                $url = 'storage/'.$profile->profile_image;
                $image = public_path ($url);
            ?>
        <?php endif; ?>

  <tr>
        <td><!-- Profile Image -->
            <img src="<?php echo e($image); ?>" alt="No Profile Image Uploaded" style="width: 100px; height: 100px; object-fit: cover;" class="img-fluid rounded-circle"></td> 
        <td>
            Name: <?php echo e($profile->last_name); ?>, <?php echo e($profile->first_name); ?><br />
            Address: <?php echo e($profile->address1); ?><br />
                    <?php echo e($profile->city); ?>, <?php echo e($profile->state); ?> <?php echo e($profile->zip_code); ?><br />            
            Email: <?php echo e($profile->user->email); ?>

        </td>
    </tr>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</table>
  
</body>
</html>
<?php /**PATH /home/kjordan/laravel/gawebapp/GAWEBAPP2/resources/views/GAChapterDirectory.blade.php ENDPATH**/ ?>