<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Forbidden</title>
    <link href="<?php echo e(asset('css/custom/app.css')); ?>" rel="stylesheet">
</head>
<body>
    <div style="text-align: center; padding: 50px;">
        <h1>403 - Forbidden</h1>
        <p>You do not have permission to access this page.</p>
        <a href="<?php echo e(url('/')); ?>">Return to Home</a>
    </div>
</body>
</html>
<?php /**PATH /home/lazhorus/laravel/spatie-permissions/spatie-role-manager/resources/views/errors/403.blade.php ENDPATH**/ ?>