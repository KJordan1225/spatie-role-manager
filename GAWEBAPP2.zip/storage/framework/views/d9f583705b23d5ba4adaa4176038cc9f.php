<div>
    <form method="POST" action="#">
        <textarea id="myeditorinstance">Hello, World!</textarea>
        <button type="submit" class="btn btn-primary btn-sm mt-2 mb-3"><i class="fa-solid fa-floppy-disk"></i> Submit</button>
    </form>
</div><?php /**PATH /home/lazhorus/laravel/spatie-permissions/spatie-role-manager/resources/views/components/forms/tinymce-editor.blade.php ENDPATH**/ ?>