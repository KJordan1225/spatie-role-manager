<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'modalId',
    'modalTitle' => 'Title',
    'onclick' => '#',
    'buttonText' => 'Save',
    'closeModal' => '',
    'size' => 'lg',
    'backDrop' => null,
    'modalFade' => 'fade',
    'onclickOnclose' => '',
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'modalId',
    'modalTitle' => 'Title',
    'onclick' => '#',
    'buttonText' => 'Save',
    'closeModal' => '',
    'size' => 'lg',
    'backDrop' => null,
    'modalFade' => 'fade',
    'onclickOnclose' => '',
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>


<div class="modal <?php echo e($modalFade); ?> custom-modal" id="<?php echo e($modalId); ?>" tabindex="-1" role="dialog"
    aria-labelledby="<?php echo e($modalId); ?>Label" aria-hidden="true" data-bs-backdrop="<?php echo e($backDrop); ?>">
    <div class="modal-dialog custom-dialog modal-<?php echo e($size); ?>" role="document">
        <div class="modal-content custom-content">
            <div class="modal-header custom-header p-1">
                <h5 class="modal-title custom-title" id="<?php echo e($modalId); ?>Label"><?php echo e($modalTitle); ?></h5>
                <button type="button" class="close custom-close" onclick="<?php echo e($closeModal); ?>()" data-bs-toggle="modal"
                    data-bs-target="#<?php echo e($modalId); ?>" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body p-3">

                <?php echo e($slot); ?>


            </div>
            <div class="modal-footer custom-footer p-2">
                <button type="submit" class="btn btn-primary custom-button"
                    onclick="<?php echo e($onclick); ?>"><?php echo e($buttonText); ?></button>
                <?php if($onclickOnclose): ?>
                    <button type="submit" name="type" value="new" class="btn btn-primary custom-button"
                        onclick="saveFolderCategoryTag('new')">Save &
                        New</button>
                <?php endif; ?>
                <button type="button" onclick="<?php echo e($closeModal); ?>()" data-bs-toggle="modal"
                    data-bs-target="#<?php echo e($modalId); ?>" class="btn btn-secondary custom-button-close"
                    data-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>
<?php /**PATH /home/lazhorus/laravel/spatie-permissions/spatie-role-manager/resources/views/components/modal.blade.php ENDPATH**/ ?>