<?php $__env->startSection('content'); ?>
<div class="row" style="margin-left: 250px;">
    <div class="col-lg-12 margin-tb">
        <div class="pull-left">
            <h2>User Management</h2>
        </div>
        <div class="pull-right">
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('role-create')): ?>
            <a class="btn btn-success btn-sm mb-2" href="<?php echo e(route('manage.users.create')); ?>"><i class="fa fa-plus"></i> Create New User</a>
        <?php endif; ?>
        </div>
    </div>
</div>

<?php $__sessionArgs = ['success'];
if (session()->has($__sessionArgs[0])) :
if (isset($value)) { $__sessionPrevious[] = $value; }
$value = session()->get($__sessionArgs[0]); ?>
    <div class="alert alert-success" role="alert" style="margin-left: 250px;"> 
        <?php echo e($value); ?>

    </div>
<?php unset($value);
if (isset($__sessionPrevious) && !empty($__sessionPrevious)) { $value = array_pop($__sessionPrevious); }
if (isset($__sessionPrevious) && empty($__sessionPrevious)) { unset($__sessionPrevious); }
endif;
unset($__sessionArgs); ?>

<table class="table table-bordered" style="margin-left: 250px;">
  <tr>
     <th width="100px">No</th>
     <th width="100px">Name</th>
     <th width="150px">Email</th>
	 <th width="100px">Active</th>
	 <th width="280px">Action</th>
  </tr>
    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>    
    <tr>
        <td><?php echo e(++$i); ?></td>
        <td><?php echo e($user->name); ?></td>
		<td><?php echo e($user->email); ?></td>
		<td>
            <input type="checkbox" id="active" value="1" name="is_active[<?php echo e($user->id); ?>]" <?php echo e($user->is_active ? 'checked' : ''); ?>>
        </td>
        <td>
            <a class="btn btn-info btn-sm" href="<?php echo e(route('manage.users.show',$user->id)); ?>"><i class="fa-solid fa-list"></i> Show</a>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('user-edit')): ?>
                <a class="btn btn-primary btn-sm" href="<?php echo e(route('manage.users.edit',$user->id)); ?>"><i class="fa-solid fa-pen-to-square"></i> Edit</a>
            <?php endif; ?>

             <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('user-delete')): ?>
            <form method="POST" action="<?php echo e(route('manage.users.destroy', $user->id)); ?>" style="display:inline">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>

                <button type="submit" class="btn btn-danger btn-sm" onclick="return confirmDelete(this);">Delete</button>
            </form>
            <?php endif; ?>
        </td>
    </tr>    
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <?php echo $users->links('pagination::bootstrap-5'); ?> 

</table>

<div class="row" style="margin-left: 250px;">
    <div class="col-xs-12 col-sm-12 col-md-12 text-center">
        <a href="<?php echo e(route('manage.users.listIsActive')); ?>" class="btn btn-primary btn-sm mt-2 mb-3">Update Active Users</a>
    </div>
</div>

<script>
    function confirmDelete(button) {
        // Confirm before submission
        return confirm("Are you sure you want to delete this user?"); }
     
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make($layout, array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/lazhorus/laravel/spatie-permissions/spatie-role-manager/resources/views/manage/users/index.blade.php ENDPATH**/ ?>