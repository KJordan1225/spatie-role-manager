<?php if (isset($component)) { $__componentOriginal9f64f32e90b9102968f2bc548315018c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9f64f32e90b9102968f2bc548315018c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.modal','data' => ['modalId' => 'createFolderModal','modalTitle' => 'New Workspace','backDrop' => 'static','modalFade' => '','onclick' => 'saveFolderForm(\''.e(route('folders.store')).'\')','closeModal' => 'closeFolderModal']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['modalId' => 'createFolderModal','modalTitle' => 'New Workspace','backDrop' => 'static','modalFade' => '','onclick' => 'saveFolderForm(\''.e(route('folders.store')).'\')','closeModal' => 'closeFolderModal']); ?>
    <form id="FolderCreateForm">
        <div class="error-message"></div>
        <!-- URL Input -->
        <label for="fileName" class="custom-label">Name</label>
        <div class="form-group col-md-6">
            <input type="text" autocomplete="false" placeholder="E.g Invoice"
                class="form-control custom-input-lg col-md-6" id="folderNameInput" name="folder_name">
        </div>
        <div class="form-group col-md-6">
            <label for="requestFolderNameInput" class="custom-label mt-3">Parent Workspaces</label>
            <select name="parent_id" id="folderParentNameInput" class="form-control custom-input custom-select">
                <option value=""></option>
                <?php echo generateDropdownOptions(); ?>

            </select>
        </div>
        <div class="form-group1">
            <label for="requestFolderNameInput" class="custom-label">Tags</label>
            <div class="form-group1">
                <div id="renderFolderCategoryHtml">

                </div>
            </div>
            <div class="form-group">
                <a href="#" class="custom-a" onclick="FolderTagsModal()">Add Tag Line</a>
            </div>
        </div>
    </form>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9f64f32e90b9102968f2bc548315018c)): ?>
<?php $attributes = $__attributesOriginal9f64f32e90b9102968f2bc548315018c; ?>
<?php unset($__attributesOriginal9f64f32e90b9102968f2bc548315018c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9f64f32e90b9102968f2bc548315018c)): ?>
<?php $component = $__componentOriginal9f64f32e90b9102968f2bc548315018c; ?>
<?php unset($__componentOriginal9f64f32e90b9102968f2bc548315018c); ?>
<?php endif; ?>


<?php if (! $__env->hasRenderedOnce('c3ae659a-8766-4ef9-b683-62c38bc0484b')): $__env->markAsRenderedOnce('c3ae659a-8766-4ef9-b683-62c38bc0484b'); ?>
    <script src="<?php echo e(asset('custom-js/addFolder.js')); ?>"></script>
<?php endif; ?>
<?php /**PATH /home/lazhorus/laravel/spatie-permissions/spatie-role-manager/resources/views/folders/modals/addFolder.blade.php ENDPATH**/ ?>