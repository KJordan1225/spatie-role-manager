<?php $__env->startSection('content'); ?>
<div class="row" style="margin-left: 250px;">
    <div class="col-lg-12 margin-tb">
        <div class="pull-left">
            <h2>Edit User Profile</h2>
        </div>
        <div class="pull-right">
            <a class="btn btn-primary btn-sm mb-2" href="<?php echo e(route('manage.user_profiles.index')); ?>"><i class="fa fa-arrow-left"></i> Back</a>
        </div>
    </div>
</div>

<?php if(count($errors) > 0): ?>
    <div class="alert alert-danger" style="margin-left: 250px;">
      <strong>Whoops!</strong> There were some problems with your input.<br><br>
      <ul>
         <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
           <li><?php echo e($error); ?></li>
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </ul>
    </div>
<?php endif; ?>

<form method="POST" action="<?php echo e(route('manage.user_profiles.update', $user->id)); ?>">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>

    <div class="row" style="margin-left: 250px;">
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>First Name:</strong>
                <input type="text" name="first_name" placeholder="FirstName" class="form-control" value="<?php echo e($userProfile->first_name); ?>">
            </div>
        </div>
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Last Name:</strong>
                <input type="text" name="last_name" placeholder="LastName" class="form-control" value="<?php echo e($userProfile->last_name); ?>">
            </div>
        </div>
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Address ln 1:</strong>
                <input type="text" name="address1" placeholder="Address1" class="form-control" value="<?php echo e($userProfile->address1); ?>">
            </div>
        </div>
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Address ln 2:</strong>
                <input type="text" name="address2" placeholder="Address2" class="form-control" value="<?php echo e($userProfile->address2); ?>">
            </div>
        </div>
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>City:</strong>
                <input type="text" name="city" placeholder="City" class="form-control" value="<?php echo e($userProfile->city); ?>">
            </div>
        </div>
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>State:</strong>
                <input type="text" name="state" placeholder="State" class="form-control" value="<?php echo e($userProfile->state); ?>">
            </div>
        </div>
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Zip Code:</strong>
                <input type="text" name="zip_code" placeholder="ZipCode" class="form-control" value="<?php echo e($userProfile->zip_code); ?>">
            </div>
        </div>
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Phone Number:</strong>
                <input type="text" name="phone_number" placeholder="Phoneumber" class="form-control" value="<?php echo e($userProfile->phone_number); ?>">
            </div>
        </div>
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Phone Type:</strong>
                <select name="phone_type" id="status">
                    <option value="mobile" <?php echo e($userProfile->phone_type == 'mobile' ? 'selected' : ''); ?>>Mobile</option>
                    <option value="landline" <?php echo e($userProfile->phone_type == 'landline' ? 'selected' : ''); ?>>Landline</option>
                </select>
            </div>
        </div>
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>BirthDate:</strong>
                <input type="text" name="dob" placeholder="YYYY-MM-DD" class="form-control" value="<?php echo e($userProfile->dob); ?>">
            </div>
        </div>
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Queversary:</strong>
                <input type="text" name="queversary" placeholder="YYYY-MM-DD" class="form-control" value="<?php echo e($userProfile->queversary); ?>">
            </div>
        </div>        
        <div class="col-xs-12 col-sm-12 col-md-12 text-center">
            <button type="submit" class="btn btn-primary btn-sm mt-2 mb-3"><i class="fa-solid fa-floppy-disk"></i> Submit</button>
        </div>
    </div>    
</form>
<br />
<br />
<?php if($userProfile->profile_image): ?>   
    <div class="row" style="margin-left: 250px;">
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                 <img src="<?php echo e(asset('storage/' . $userProfile->profile_image)); ?>" alt="Profile Image" style="width: 150px; height: 150px; border: 1px solid #000; padding: 5px; margin: 10px;">
            </div>
        </div>
    </div>
<?php endif; ?>
<br />
UPLOAD PROFILE PICTURE
<hr />
<form action="<?php echo e(route('manage.user_profiles.upload_pics', $user->id)); ?>" method="POST" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>

    <div class="row" style="margin-left: 250px;">
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <input type="file" name="profile_image" id="profile_image">
                <button type="submit">Upload Profile Picture</button>
            </div>
        </div>
    </div>
</form>
<br />
<hr />

<?php $__env->stopSection(); ?>

<?php echo $__env->make($layout, array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/kjordan/laravel/gawebapp/GAWEBAPP2/resources/views/manage/user_profiles/edit.blade.php ENDPATH**/ ?>