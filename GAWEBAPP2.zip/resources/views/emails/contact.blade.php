<div>
    <h3>Name : {{ $name }}</h3>
    <h3>Email : {{ $email }}</h3>
    <h3>Message : {{ $messageContent }}</h3>
</div>