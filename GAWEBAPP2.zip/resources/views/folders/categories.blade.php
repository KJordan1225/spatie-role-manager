@if (!is_null($folder))
    {!! renderTagsWithCategories($folder) !!}
@endif
